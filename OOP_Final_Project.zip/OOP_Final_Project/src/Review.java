// ============================================================
// Review.java - Client review for a completed order
// OOP Concept: Encapsulation
// ============================================================

public class Review {

    private int    reviewId;
    private int    orderId;
    private int    clientId;
    private String clientName;
    private int    freelancerId;
    private double rating;      // 1 to 5
    private String comment;
    private String reviewDate;

    public Review(int reviewId, int orderId, int clientId, String clientName,
                  int freelancerId, double rating, String comment, String reviewDate) {
        this.reviewId     = reviewId;
        this.orderId      = orderId;
        this.clientId     = clientId;
        this.clientName   = clientName;
        this.freelancerId = freelancerId;
        this.rating       = rating;
        this.comment      = comment;
        this.reviewDate   = reviewDate;
    }

    // Getters
    public int    getReviewId()     { return reviewId; }
    public int    getOrderId()      { return orderId; }
    public int    getClientId()     { return clientId; }
    public String getClientName()   { return clientName; }
    public int    getFreelancerId() { return freelancerId; }
    public double getRating()       { return rating; }
    public String getComment()      { return comment; }
    public String getReviewDate()   { return reviewDate; }

    public void displayReview() {
        System.out.println("------------------------------------------");
        System.out.println("Review ID   : " + reviewId);
        System.out.println("From        : " + clientName);
        System.out.printf ("Rating      : %.1f / 5.0%n", rating);
        System.out.println("Comment     : " + comment);
        System.out.println("Date        : " + reviewDate);
    }

    // Use | because comment can contain commas
    public String toFileString() {
        return reviewId + "|" + orderId + "|" + clientId + "|" + clientName + "|"
                + freelancerId + "|" + rating + "|" + comment + "|" + reviewDate;
    }

    public static Review fromFileString(String line) {
        String[] p = line.split("\\|");
        return new Review(
                Integer.parseInt(p[0].trim()),
                Integer.parseInt(p[1].trim()),
                Integer.parseInt(p[2].trim()),
                p[3].trim(),
                Integer.parseInt(p[4].trim()),
                Double.parseDouble(p[5].trim()),
                p[6].trim(),
                p[7].trim()
        );
    }

    @Override
    public String toString() {
        return "Review #" + reviewId + " by " + clientName
                + " | Rating: " + rating + " | " + comment;
    }
}