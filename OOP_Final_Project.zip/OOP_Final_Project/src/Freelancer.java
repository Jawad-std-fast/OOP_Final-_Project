

public class Freelancer extends User {

    private String skills;
    private double hourlyRate;
    private double earnings;
    private double rating;
    private int    reviewCount;

    public Freelancer(int userId, String name, String email, String password,
                      String skills, double hourlyRate) {
        super(userId, name, email, password);
        this.skills      = skills;
        this.hourlyRate  = hourlyRate;
        this.earnings    = 0.0;
        this.rating      = 0.0;
        this.reviewCount = 0;
    }

    public Freelancer(int userId, String name, String email, String password,
                      String skills, double hourlyRate,
                      double earnings, double rating, int reviewCount) {
        super(userId, name, email, password);
        this.skills      = skills;
        this.hourlyRate  = hourlyRate;
        this.earnings    = earnings;
        this.rating      = rating;
        this.reviewCount = reviewCount;
    }

    public String getSkills()      { return skills; }
    public double getHourlyRate()  { return hourlyRate; }
    public double getEarnings()    { return earnings; }
    public double getRating()      { return rating; }
    public int    getReviewCount() { return reviewCount; }

    public void setSkills(String skills)         { this.skills = skills; }
    public void setHourlyRate(double rate)        { this.hourlyRate = rate; }

    public void addEarnings(double amount) {
        earnings += amount;
    }

    public void addRating(double newScore) {
        rating = ((rating * reviewCount) + newScore) / (reviewCount + 1);
        reviewCount++;
    }

    @Override
    public void displayDetails() {
        System.out.println("=== FREELANCER PROFILE ===");
        System.out.println("ID         : " + getUserId());
        System.out.println("Name       : " + getName());
        System.out.println("Email      : " + getEmail());
        System.out.println("Skills     : " + skills);
        System.out.println("Hourly Rate: Rs. " + hourlyRate);
        System.out.println("Earnings   : Rs. " + earnings);
        System.out.printf ("Rating     : %.1f / 5.0 (%d reviews)%n", rating, reviewCount);
        System.out.println("Role       : " + getRole());
    }

    @Override
    public String getRole() {
        return "Freelancer";
    }

    public String toFileString() {
        return getUserId() + "," + getName() + "," + getEmail() + ","
                + getPassword() + "," + skills + "," + hourlyRate + ","
                + earnings + "," + rating + "," + reviewCount;
    }

    public static Freelancer fromFileString(String line) {
        String[] parts = line.split(",");
        return new Freelancer(
                Integer.parseInt(parts[0].trim()),
                parts[1].trim(),
                parts[2].trim(),
                parts[3].trim(),
                parts[4].trim(),
                Double.parseDouble(parts[5].trim()),
                Double.parseDouble(parts[6].trim()),
                Double.parseDouble(parts[7].trim()),
                Integer.parseInt(parts[8].trim())
        );
    }
}