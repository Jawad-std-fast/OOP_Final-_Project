// ============================================================
// FileHandler.java - All file read/write operations
// OOP Concept: Encapsulation of file handling logic
// Java Concept: File Handling using FileWriter, FileReader,
//               BufferedReader, BufferedWriter
// ============================================================

import java.io.*;
import java.util.ArrayList;

public class FileHandler {

    // ---- File paths (relative to where the program runs) ----
    private static final String CLIENTS_FILE    = "data/clients.txt";
    private static final String FREELANCERS_FILE = "data/freelancers.txt";
    private static final String SERVICES_FILE   = "data/services.txt";
    private static final String ORDERS_FILE     = "data/orders.txt";
    private static final String PAYMENTS_FILE   = "data/payments.txt";
    private static final String REVIEWS_FILE    = "data/reviews.txt";

    // ---- Make sure the data folder exists ----
    public static void initDataFolder() {
        File dir = new File("data");
        if (!dir.exists()) {
            dir.mkdir();
        }
    }

    // ============================================================
    //  Generic helpers: write all lines / read all lines
    // ============================================================

    // Write an ArrayList of strings to a file (overwrites)
    private static void writeLines(String filepath, ArrayList<String> lines) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
            for (String line : lines) {
                bw.write(line);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            System.out.println("Error writing to file: " + filepath);
            e.printStackTrace();
        }
    }

    // Append a single line to a file
    private static void appendLine(String filepath, String line) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filepath, true)); // true = append
            bw.write(line);
            bw.newLine();
            bw.close();
        } catch (IOException e) {
            System.out.println("Error appending to file: " + filepath);
        }
    }

    // Read all lines from a file into an ArrayList
    private static ArrayList<String> readLines(String filepath) {
        ArrayList<String> lines = new ArrayList<String>();
        try {
            File f = new File(filepath);
            if (!f.exists()) return lines; // return empty list if file doesn't exist

            BufferedReader br = new BufferedReader(new FileReader(filepath));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    lines.add(line);
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Error reading file: " + filepath);
        }
        return lines;
    }

    // ============================================================
    //  CLIENT methods
    // ============================================================

    public static void saveClient(Client c) {
        appendLine(CLIENTS_FILE, c.toFileString());
    }

    public static void saveAllClients(ArrayList<Client> clients) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Client c : clients) {
            lines.add(c.toFileString());
        }
        writeLines(CLIENTS_FILE, lines);
    }

    public static ArrayList<Client> loadClients() {
        ArrayList<Client> clients = new ArrayList<Client>();
        ArrayList<String> lines = readLines(CLIENTS_FILE);
        for (String line : lines) {
            try {
                clients.add(Client.fromFileString(line));
            } catch (Exception e) {
                System.out.println("Skipping malformed client line: " + line);
            }
        }
        return clients;
    }

    // ============================================================
    //  FREELANCER methods
    // ============================================================

    public static void saveFreelancer(Freelancer f) {
        appendLine(FREELANCERS_FILE, f.toFileString());
    }

    public static void saveAllFreelancers(ArrayList<Freelancer> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Freelancer f : list) {
            lines.add(f.toFileString());
        }
        writeLines(FREELANCERS_FILE, lines);
    }

    public static ArrayList<Freelancer> loadFreelancers() {
        ArrayList<Freelancer> list = new ArrayList<Freelancer>();
        ArrayList<String> lines = readLines(FREELANCERS_FILE);
        for (String line : lines) {
            try {
                list.add(Freelancer.fromFileString(line));
            } catch (Exception e) {
                System.out.println("Skipping malformed freelancer line: " + line);
            }
        }
        return list;
    }

    // ============================================================
    //  SERVICE methods
    // ============================================================

    public static void saveService(Service s) {
        appendLine(SERVICES_FILE, s.toFileString());
    }

    public static void saveAllServices(ArrayList<Service> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Service s : list) {
            lines.add(s.toFileString());
        }
        writeLines(SERVICES_FILE, lines);
    }

    public static ArrayList<Service> loadServices() {
        ArrayList<Service> list = new ArrayList<Service>();
        ArrayList<String> lines = readLines(SERVICES_FILE);
        for (String line : lines) {
            try {
                list.add(Service.fromFileString(line));
            } catch (Exception e) {
                System.out.println("Skipping malformed service line: " + line);
            }
        }
        return list;
    }

    // ============================================================
    //  ORDER methods
    // ============================================================

    public static void saveOrder(Order o) {
        appendLine(ORDERS_FILE, o.toFileString());
    }

    public static void saveAllOrders(ArrayList<Order> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Order o : list) {
            lines.add(o.toFileString());
        }
        writeLines(ORDERS_FILE, lines);
    }

    public static ArrayList<Order> loadOrders() {
        ArrayList<Order> list = new ArrayList<Order>();
        ArrayList<String> lines = readLines(ORDERS_FILE);
        for (String line : lines) {
            try {
                list.add(Order.fromFileString(line));
            } catch (Exception e) {
                System.out.println("Skipping malformed order line: " + line);
            }
        }
        return list;
    }

    // ============================================================
    //  PAYMENT methods
    // ============================================================

    public static void savePayment(Payment p) {
        appendLine(PAYMENTS_FILE, p.toFileString());
    }

    public static void saveAllPayments(ArrayList<Payment> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Payment p : list) {
            lines.add(p.toFileString());
        }
        writeLines(PAYMENTS_FILE, lines);
    }

    public static ArrayList<Payment> loadPayments() {
        ArrayList<Payment> list = new ArrayList<Payment>();
        ArrayList<String> lines = readLines(PAYMENTS_FILE);
        for (String line : lines) {
            try {
                list.add(Payment.fromFileString(line));
            } catch (Exception e) {
                System.out.println("Skipping malformed payment line: " + line);
            }
        }
        return list;
    }

    // ============================================================
    //  REVIEW methods
    // ============================================================

    public static void saveReview(Review r) {
        appendLine(REVIEWS_FILE, r.toFileString());
    }

    public static void saveAllReviews(ArrayList<Review> list) {
        ArrayList<String> lines = new ArrayList<String>();
        for (Review r : list) {
            lines.add(r.toFileString());
        }
        writeLines(REVIEWS_FILE, lines);
    }

    public static ArrayList<Review> loadReviews() {
        ArrayList<Review> list = new ArrayList<Review>();
        ArrayList<String> lines = readLines(REVIEWS_FILE);
        for (String line : lines) {
            try {
                list.add(Review.fromFileString(line));
            } catch (Exception e) {
                System.out.println("Skipping malformed review line: " + line);
            }
        }
        return list;
    }
}