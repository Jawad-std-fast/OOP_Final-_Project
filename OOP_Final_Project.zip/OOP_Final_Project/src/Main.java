public class Main {
    public static void main(String[] args) {
        // Ensure the data folder exists before loading/saving
        FileHandler.initDataFolder();

        Marketplace marketplace = new Marketplace();
        marketplace.start();
    }
}