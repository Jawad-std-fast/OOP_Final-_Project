/**
 * Abstract base class for all users.
 * Implements Displayable to force subclasses to provide displayDetails().
 */
public abstract class User implements Displayable {

    private int userId;
    private String name;
    private String email;
    private String password;

    public User(int userId, String name, String email, String password) {
        this.userId   = userId;
        this.name     = name;
        this.email    = email;
        this.password = password;
    }

    // Getters
    public int    getUserId()   { return userId; }
    public String getName()     { return name; }
    public String getEmail()    { return email; }
    public String getPassword() { return password; }

    // Setters
    public void setName(String name)         { this.name = name; }
    public void setEmail(String email)       { this.email = email; }
    public void setPassword(String password) { this.password = password; }

    /**
     * Subclasses must implement this method to show their specific profile.
     * Replaces the old abstract method displayProfile().
     */
    @Override
    public abstract void displayDetails();

    // Identifying role (polymorphism)
    public String getRole() {
        return "User";
    }

    @Override
    public String toString() {
        return "ID: " + userId + " | Name: " + name + " | Email: " + email;
    }
}