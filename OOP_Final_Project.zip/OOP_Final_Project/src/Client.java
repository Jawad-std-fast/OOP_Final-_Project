
public class Client extends User {

    private Wallet wallet;


    public Client(int userId, String name, String email, String password, double initialBalance) {
        super(userId, name, email, password);
        this.wallet = new Wallet(initialBalance);
    }



    public double getWalletBalance() {
        return wallet.getBalance();
    }


    public void setWalletBalance(double amt) {
        wallet.setBalance(amt);
    }

    public void addFunds(double amount) {
        wallet.deposit(amount);
        System.out.println("Rs. " + amount + " added. New balance: Rs. " + wallet.getBalance());
    }

    public boolean deductFunds(double amount) {
        if (wallet.withdraw(amount)) {
            return true;
        }
        System.out.println("Insufficient wallet balance!");
        return false;
    }

    @Override
    public void displayDetails() {
        System.out.println("=== CLIENT PROFILE ===");
        System.out.println("ID       : " + getUserId());
        System.out.println("Name     : " + getName());
        System.out.println("Email    : " + getEmail());
        System.out.println("Wallet   : Rs. " + wallet.getBalance());
        System.out.println("Role     : " + getRole());
    }

    @Override
    public String getRole() {
        return "Client";
    }


    public String toFileString() {
        return getUserId() + "," + getName() + "," + getEmail() + ","
                + getPassword() + "," + wallet.getBalance();
    }

    public static Client fromFileString(String line) {
        String[] parts = line.split(",");
        int id = Integer.parseInt(parts[0].trim());
        String name = parts[1].trim();
        String email = parts[2].trim();
        String pass = parts[3].trim();
        double bal = Double.parseDouble(parts[4].trim());
        return new Client(id, name, email, pass, bal);
    }
}