/**
 * Client class – inherits from User, has a Wallet (composition).
 * OOP Concepts: Inheritance, Polymorphism, Composition, Encapsulation.
 */
public class Client extends User {

    // Replaces "private double walletBalance" with a Wallet object
    private Wallet wallet;

    /**
     * Constructor for new registration.
     * @param userId          unique ID
     * @param name            client's name
     * @param email           email address
     * @param password        login password
     * @param initialBalance  starting wallet amount
     */
    public Client(int userId, String name, String email, String password, double initialBalance) {
        super(userId, name, email, password);   // call parent constructor
        this.wallet = new Wallet(initialBalance);
    }

    // ---- Wallet-related methods ----

    public double getWalletBalance() {
        return wallet.getBalance();
    }

    /**
     * Directly overwrite wallet balance (used when loading from file).
     */
    public void setWalletBalance(double amt) {
        wallet.setBalance(amt);
    }

    public void addFunds(double amount) {
        wallet.deposit(amount);
        System.out.println("Rs. " + amount + " added. New balance: Rs. " + wallet.getBalance());
    }

    /**
     * Withdraw money from wallet. Returns true if successful, false if insufficient.
     */
    public boolean deductFunds(double amount) {
        if (wallet.withdraw(amount)) {
            return true;
        }
        System.out.println("Insufficient wallet balance!");
        return false;
    }

    // ---- Polymorphic overrides ----

    @Override
    public void displayDetails() {
        System.out.println("=== CLIENT PROFILE ===");
        System.out.println("ID       : " + getUserId());
        System.out.println("Name     : " + getName());
        System.out.println("Email    : " + getEmail());
        System.out.println("Wallet   : Rs. " + wallet.getBalance());
        System.out.println("Role     : " + getRole());
    }

    @Override
    public String getRole() {
        return "Client";
    }

    // ---- File persistence ----

    public String toFileString() {
        return getUserId() + "," + getName() + "," + getEmail() + ","
                + getPassword() + "," + wallet.getBalance();
    }

    public static Client fromFileString(String line) {
        String[] parts = line.split(",");
        int id = Integer.parseInt(parts[0].trim());
        String name = parts[1].trim();
        String email = parts[2].trim();
        String pass = parts[3].trim();
        double bal = Double.parseDouble(parts[4].trim());
        return new Client(id, name, email, pass, bal);
    }
}