public class Main {
    public static void main(String[] args) {
        FileHandler.initDataFolder();
        Marketplace marketplace = new Marketplace();
        marketplace.start();
    }
}