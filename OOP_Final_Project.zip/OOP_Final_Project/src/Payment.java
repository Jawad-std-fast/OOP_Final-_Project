

public class Payment {

    public static final String SUCCESS = "Success";
    public static final String FAILED  = "Failed";
    public static final String REFUNDED = "Refunded";

    private int    paymentId;
    private int    orderId;
    private int    clientId;
    private double amount;
    private String status;
    private String paymentDate;

    public Payment(int paymentId, int orderId, int clientId,
                   double amount, String status, String paymentDate) {
        this.paymentId   = paymentId;
        this.orderId     = orderId;
        this.clientId    = clientId;
        this.amount      = amount;
        this.status      = status;
        this.paymentDate = paymentDate;
    }


    public int    getPaymentId()   { return paymentId; }
    public int    getOrderId()     { return orderId; }
    public int    getClientId()    { return clientId; }
    public double getAmount()      { return amount; }
    public String getStatus()      { return status; }
    public String getPaymentDate() { return paymentDate; }

    public void setStatus(String status) { this.status = status; }

    public void displayPayment() {
        System.out.println("------------------------------------------");
        System.out.println("Payment ID  : " + paymentId);
        System.out.println("Order ID    : " + orderId);
        System.out.println("Client ID   : " + clientId);
        System.out.printf ("Amount      : Rs. %.2f%n", amount);
        System.out.println("Status      : " + status);
        System.out.println("Date        : " + paymentDate);
    }

    public String toFileString() {
        return paymentId + "," + orderId + "," + clientId + ","
                + amount + "," + status + "," + paymentDate;
    }

    public static Payment fromFileString(String line) {
        String[] p = line.split(",");
        return new Payment(
                Integer.parseInt(p[0].trim()),
                Integer.parseInt(p[1].trim()),
                Integer.parseInt(p[2].trim()),
                Double.parseDouble(p[3].trim()),
                p[4].trim(),
                p[5].trim()
        );
    }

    @Override
    public String toString() {
        return "Payment #" + paymentId + " | Order #" + orderId
                + " | Rs." + amount + " | " + status;
    }
}