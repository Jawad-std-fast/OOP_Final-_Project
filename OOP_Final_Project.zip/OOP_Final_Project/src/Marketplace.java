// ============================================================
// Marketplace.java - Core system logic
// Manages all ArrayLists, menus, and business operations
// Java Concepts: ArrayList, Scanner, loops, conditionals,
//               static methods, ID generation
// ============================================================

import java.util.ArrayList;
import java.util.Scanner;

public class Marketplace {

    // ---- In-memory data storage using ArrayLists ----
    // ArrayList is a dynamic array that grows as needed
    private ArrayList<Client>     clients;
    private ArrayList<Freelancer> freelancers;
    private ArrayList<Service>    services;
    private ArrayList<Order>      orders;
    private ArrayList<Payment>    payments;
    private ArrayList<Review>     reviews;

    private Scanner scanner;

    // Currently logged-in user
    private Client     loggedClient;
    private Freelancer loggedFreelancer;

    // Constructor: load data from files
    public Marketplace() {
        scanner     = new Scanner(System.in);
        clients     = FileHandler.loadClients();
        freelancers = FileHandler.loadFreelancers();
        services    = FileHandler.loadServices();
        orders      = FileHandler.loadOrders();
        payments    = FileHandler.loadPayments();
        reviews     = FileHandler.loadReviews();
    }

    // ============================================================
    //  ID Generators - find max existing ID and add 1
    // ============================================================
    private int nextClientId() {
        int max = 0;
        for (Client c : clients) if (c.getUserId() > max) max = c.getUserId();
        return max + 1;
    }
    private int nextFreelancerId() {
        int max = 0;
        for (Freelancer f : freelancers) if (f.getUserId() > max) max = f.getUserId();
        return max + 1;
    }
    private int nextServiceId() {
        int max = 0;
        for (Service s : services) if (s.getServiceId() > max) max = s.getServiceId();
        return max + 1;
    }
    private int nextOrderId() {
        int max = 0;
        for (Order o : orders) if (o.getOrderId() > max) max = o.getOrderId();
        return max + 1;
    }
    private int nextPaymentId() {
        int max = 0;
        for (Payment p : payments) if (p.getPaymentId() > max) max = p.getPaymentId();
        return max + 1;
    }
    private int nextReviewId() {
        int max = 0;
        for (Review r : reviews) if (r.getReviewId() > max) max = r.getReviewId();
        return max + 1;
    }

    // ============================================================
    //  Simple date helper (avoids advanced java.time)
    // ============================================================
    private String today() {
        // Returns system date as string using java.util.Date
        java.util.Date d = new java.util.Date();
        return d.toString().substring(0, 10); // e.g. "Mon Apr 28"
    }

    // ============================================================
    //  MAIN MENU
    // ============================================================
    public void start() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║   ONLINE SERVICE MARKETPLACE SYSTEM   ║");
        System.out.println("╚══════════════════════════════════════╝");

        boolean running = true;
        while (running) {
            System.out.println("\n========== MAIN MENU ==========");
            System.out.println("1. Register as Client");
            System.out.println("2. Register as Freelancer");
            System.out.println("3. Login as Client");
            System.out.println("4. Login as Freelancer");
            System.out.println("5. Browse All Services (Guest)");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            int choice = readInt();
            switch (choice) {
                case 1: registerClient();     break;
                case 2: registerFreelancer(); break;
                case 3: loginClient();        break;
                case 4: loginFreelancer();    break;
                case 5: browseServices(null); break;
                case 0:
                    System.out.println("Thank you for using the Marketplace. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // ============================================================
    //  REGISTRATION
    // ============================================================
    private void registerClient() {
        System.out.println("\n--- Register as Client ---");
        System.out.print("Enter Name    : ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter Email   : ");
        String email = scanner.nextLine().trim();
        System.out.print("Enter Password: ");
        String pass = scanner.nextLine().trim();

        // Check email uniqueness across both clients and freelancers
        if (emailExists(email)) {
            System.out.println("Email already registered!");
            return;
        }

        Client c = new Client(nextClientId(), name, email, pass, 1000.0); // start with Rs.1000
        clients.add(c);
        FileHandler.saveClient(c);
        System.out.println("Registration successful! Welcome, " + name
                + ". Starting wallet: Rs.1000.00");
    }

    private void registerFreelancer() {
        System.out.println("\n--- Register as Freelancer ---");
        System.out.print("Enter Name       : ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter Email      : ");
        String email = scanner.nextLine().trim();
        System.out.print("Enter Password   : ");
        String pass = scanner.nextLine().trim();
        System.out.print("Enter Skills (e.g. SEO, Video Editing): ");
        String skills = scanner.nextLine().trim();
        System.out.print("Enter Hourly Rate (Rs.): ");
        double rate = readDouble();

        if (emailExists(email)) {
            System.out.println("Email already registered!");
            return;
        }

        Freelancer f = new Freelancer(nextFreelancerId(), name, email, pass, skills, rate);
        freelancers.add(f);
        FileHandler.saveFreelancer(f);
        System.out.println("Registration successful! Welcome, " + name);
    }

    // Check if email is already used
    private boolean emailExists(String email) {
        for (Client c : clients)         if (c.getEmail().equalsIgnoreCase(email)) return true;
        for (Freelancer f : freelancers) if (f.getEmail().equalsIgnoreCase(email)) return true;
        return false;
    }

    // ============================================================
    //  LOGIN
    // ============================================================
    private void loginClient() {
        System.out.println("\n--- Client Login ---");
        System.out.print("Email   : ");
        String email = scanner.nextLine().trim();
        System.out.print("Password: ");
        String pass = scanner.nextLine().trim();

        for (Client c : clients) {
            if (c.getEmail().equalsIgnoreCase(email) && c.getPassword().equals(pass)) {
                loggedClient = c;
                System.out.println("Login successful! Welcome back, " + c.getName());
                clientMenu();
                loggedClient = null;
                return;
            }
        }
        System.out.println("Invalid email or password.");
    }

    private void loginFreelancer() {
        System.out.println("\n--- Freelancer Login ---");
        System.out.print("Email   : ");
        String email = scanner.nextLine().trim();
        System.out.print("Password: ");
        String pass = scanner.nextLine().trim();

        for (Freelancer f : freelancers) {
            if (f.getEmail().equalsIgnoreCase(email) && f.getPassword().equals(pass)) {
                loggedFreelancer = f;
                System.out.println("Login successful! Welcome back, " + f.getName());
                freelancerMenu();
                loggedFreelancer = null;
                return;
            }
        }
        System.out.println("Invalid email or password.");
    }

    // ============================================================
    //  CLIENT MENU (after login)
    // ============================================================
    private void clientMenu() {
        boolean active = true;
        while (active) {
            System.out.println("\n===== CLIENT MENU (" + loggedClient.getName() + ") =====");
            System.out.println("1. Browse All Services");
            System.out.println("2. Search Services by Category");
            System.out.println("3. Place Order");
            System.out.println("4. View My Orders");
            System.out.println("5. Cancel an Order");
            System.out.println("6. Leave a Review");
            System.out.println("7. View My Profile");
            System.out.println("8. Add Funds to Wallet");
            System.out.println("9. View My Payment History");
            System.out.println("0. Logout");
            System.out.print("Choice: ");

            int ch = readInt();
            switch (ch) {
                case 1: browseServices(null);              break;
                case 2: searchByCategory();                break;
                case 3: placeOrder();                      break;
                case 4: viewClientOrders();                break;
                case 5: cancelOrder();                     break;
                case 6: leaveReview();                     break;
                case 7: loggedClient.displayDetails();     break;
                case 8: addFunds();                        break;
                case 9: viewClientPayments();              break;
                case 0: active = false;                    break;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    // ============================================================
    //  FREELANCER MENU (after login)
    // ============================================================
    private void freelancerMenu() {
        boolean active = true;
        while (active) {
            System.out.println("\n===== FREELANCER MENU (" + loggedFreelancer.getName() + ") =====");
            System.out.println("1. Add a New Service");
            System.out.println("2. View My Services");
            System.out.println("3. Update a Service");
            System.out.println("4. Delete a Service");
            System.out.println("5. View Orders I Received");
            System.out.println("6. Update Order Status");
            System.out.println("7. View Reviews About Me");
            System.out.println("8. View My Profile & Earnings");
            System.out.println("0. Logout");
            System.out.print("Choice: ");

            int ch = readInt();
            switch (ch) {
                case 1: addService();                          break;
                case 2: viewMyServices();                      break;
                case 3: updateService();                       break;
                case 4: deleteService();                       break;
                case 5: viewFreelancerOrders();                break;
                case 6: updateOrderStatus();                   break;
                case 7: viewMyReviews();                       break;
                case 8: loggedFreelancer.displayDetails(); break;
                case 0: active = false;                        break;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    // ============================================================
    //  SERVICE OPERATIONS
    // ============================================================

    private void browseServices(String categoryFilter) {
        System.out.println("\n--- Available Services ---");
        boolean found = false;
        for (Service s : services) {
            if (categoryFilter == null || s.getCategory().equalsIgnoreCase(categoryFilter)) {
                s.displayService();
                found = true;
            }
        }
        if (!found) System.out.println("No services found.");
    }

    private void searchByCategory() {
        System.out.println("\nCategories: SEO | Video Editing | Digital Marketing | Graphic Design | Content Writing");
        System.out.print("Enter category: ");
        String cat = scanner.nextLine().trim();
        browseServices(cat);
    }

    private void addService() {
        System.out.println("\n--- Add New Service ---");
        System.out.print("Title       : ");
        String title = scanner.nextLine().trim();
        System.out.print("Description : ");
        String desc = scanner.nextLine().trim();
        System.out.println("Category options: SEO | Video Editing | Digital Marketing | Graphic Design | Content Writing");
        System.out.print("Category    : ");
        String cat = scanner.nextLine().trim();
        System.out.print("Price (Rs.) : ");
        double price = readDouble();

        Service s = new Service(nextServiceId(), title, desc, cat, price,
                loggedFreelancer.getUserId(), loggedFreelancer.getName());
        services.add(s);
        FileHandler.saveAllServices(services);
        System.out.println("Service added successfully! Service ID: " + s.getServiceId());
    }

    private void viewMyServices() {
        System.out.println("\n--- My Services ---");
        boolean found = false;
        for (Service s : services) {
            if (s.getFreelancerId() == loggedFreelancer.getUserId()) {
                s.displayService();
                found = true;
            }
        }
        if (!found) System.out.println("You have not added any services yet.");
    }

    private void updateService() {
        viewMyServices();
        System.out.print("\nEnter Service ID to update (0 to cancel): ");
        int id = readInt();
        if (id == 0) return;

        for (Service s : services) {
            if (s.getServiceId() == id && s.getFreelancerId() == loggedFreelancer.getUserId()) {
                System.out.print("New Title (Enter to keep \"" + s.getTitle() + "\"): ");
                String title = scanner.nextLine().trim();
                if (!title.isEmpty()) s.setTitle(title);

                System.out.print("New Description: ");
                String desc = scanner.nextLine().trim();
                if (!desc.isEmpty()) s.setDescription(desc);

                System.out.print("New Price (0 to keep " + s.getPrice() + "): ");
                double price = readDouble();
                if (price > 0) s.setPrice(price);

                FileHandler.saveAllServices(services);
                System.out.println("Service updated.");
                return;
            }
        }
        System.out.println("Service not found or not yours.");
    }

    private void deleteService() {
        viewMyServices();
        System.out.print("\nEnter Service ID to delete (0 to cancel): ");
        int id = readInt();
        if (id == 0) return;

        for (int i = 0; i < services.size(); i++) {
            Service s = services.get(i);
            if (s.getServiceId() == id && s.getFreelancerId() == loggedFreelancer.getUserId()) {
                services.remove(i);
                FileHandler.saveAllServices(services);
                System.out.println("Service deleted.");
                return;
            }
        }
        System.out.println("Service not found or not yours.");
    }

    // ============================================================
    //  ORDER OPERATIONS
    // ============================================================

    private void placeOrder() {
        browseServices(null);
        System.out.print("\nEnter Service ID to order (0 to cancel): ");
        int sid = readInt();
        if (sid == 0) return;

        Service chosen = null;
        for (Service s : services) {
            if (s.getServiceId() == sid) { chosen = s; break; }
        }
        if (chosen == null) { System.out.println("Service not found."); return; }
        if (chosen.getFreelancerId() == loggedClient.getUserId()) {
            System.out.println("You cannot order your own service.");
            return;
        }

        System.out.println("\nService: " + chosen.getTitle()
                + " | Price: Rs. " + chosen.getPrice());
        System.out.println("Your wallet: Rs. " + loggedClient.getWalletBalance());
        System.out.print("Confirm order? (yes/no): ");
        String confirm = scanner.nextLine().trim();
        if (!confirm.equalsIgnoreCase("yes")) { System.out.println("Order cancelled."); return; }

        if (!loggedClient.deductFunds(chosen.getPrice())) return; // insufficient funds

        // Create Order
        Order order = new Order(nextOrderId(), loggedClient.getUserId(), loggedClient.getName(),
                chosen.getServiceId(), chosen.getTitle(),
                chosen.getFreelancerId(), chosen.getFreelancerName(),
                chosen.getPrice(), Order.PENDING, today());
        orders.add(order);
        FileHandler.saveAllOrders(orders);

        // Create Payment
        Payment payment = new Payment(nextPaymentId(), order.getOrderId(),
                loggedClient.getUserId(), chosen.getPrice(),
                Payment.SUCCESS, today());
        payments.add(payment);
        FileHandler.saveAllPayments(payments);

        // Save updated wallet
        FileHandler.saveAllClients(clients);

        System.out.println("\nOrder placed! Order ID: " + order.getOrderId());
        System.out.println("Payment deducted: Rs. " + chosen.getPrice());
        System.out.println("Remaining wallet: Rs. " + loggedClient.getWalletBalance());
    }

    private void viewClientOrders() {
        System.out.println("\n--- My Orders ---");
        boolean found = false;
        for (Order o : orders) {
            if (o.getClientId() == loggedClient.getUserId()) {
                o.displayOrder();
                found = true;
            }
        }
        if (!found) System.out.println("You have no orders.");
    }

    private void cancelOrder() {
        viewClientOrders();
        System.out.print("\nEnter Order ID to cancel (0 to go back): ");
        int id = readInt();
        if (id == 0) return;

        for (Order o : orders) {
            if (o.getOrderId() == id && o.getClientId() == loggedClient.getUserId()) {
                if (o.getStatus().equals(Order.COMPLETED)) {
                    System.out.println("Cannot cancel a completed order.");
                    return;
                }
                if (o.getStatus().equals(Order.CANCELLED)) {
                    System.out.println("Order is already cancelled.");
                    return;
                }
                o.setStatus(Order.CANCELLED);
                // Refund to wallet
                loggedClient.addFunds(o.getAmount());
                FileHandler.saveAllOrders(orders);
                FileHandler.saveAllClients(clients);
                System.out.println("Order #" + id + " cancelled. Rs." + o.getAmount() + " refunded.");
                return;
            }
        }
        System.out.println("Order not found.");
    }

    private void viewFreelancerOrders() {
        System.out.println("\n--- Orders I Received ---");
        boolean found = false;
        for (Order o : orders) {
            if (o.getFreelancerId() == loggedFreelancer.getUserId()) {
                o.displayOrder();
                found = true;
            }
        }
        if (!found) System.out.println("No orders received yet.");
    }

    private void updateOrderStatus() {
        viewFreelancerOrders();
        System.out.print("\nEnter Order ID to update (0 to cancel): ");
        int id = readInt();
        if (id == 0) return;

        for (Order o : orders) {
            if (o.getOrderId() == id && o.getFreelancerId() == loggedFreelancer.getUserId()) {
                System.out.println("Current Status: " + o.getStatus());
                System.out.println("1. Mark as In Progress");
                System.out.println("2. Mark as Completed");
                System.out.print("Choice: ");
                int ch = readInt();
                if (ch == 1) {
                    o.setStatus(Order.IN_PROGRESS);
                    System.out.println("Status updated to In Progress.");
                } else if (ch == 2) {
                    o.setStatus(Order.COMPLETED);
                    // Add earnings to freelancer
                    loggedFreelancer.addEarnings(o.getAmount());
                    FileHandler.saveAllFreelancers(freelancers);
                    System.out.println("Status updated to Completed. Earnings: Rs." + o.getAmount());
                } else {
                    System.out.println("Invalid choice.");
                    return;
                }
                FileHandler.saveAllOrders(orders);
                return;
            }
        }
        System.out.println("Order not found.");
    }

    // ============================================================
    //  REVIEW OPERATIONS
    // ============================================================

    private void leaveReview() {
        System.out.println("\n--- Leave a Review ---");
        System.out.println("Your completed orders:");
        boolean found = false;
        for (Order o : orders) {
            if (o.getClientId() == loggedClient.getUserId()
                    && o.getStatus().equals(Order.COMPLETED)) {
                System.out.println("  " + o);
                found = true;
            }
        }
        if (!found) { System.out.println("No completed orders to review."); return; }

        System.out.print("Enter Order ID to review: ");
        int oid = readInt();

        Order target = null;
        for (Order o : orders) {
            if (o.getOrderId() == oid && o.getClientId() == loggedClient.getUserId()) {
                target = o;
                break;
            }
        }
        if (target == null) { System.out.println("Order not found."); return; }

        // Check if already reviewed
        for (Review r : reviews) {
            if (r.getOrderId() == oid) { System.out.println("Already reviewed this order."); return; }
        }

        System.out.print("Rating (1-5): ");
        double rating = readDouble();
        if (rating < 1 || rating > 5) { System.out.println("Invalid rating."); return; }

        System.out.print("Comment: ");
        String comment = scanner.nextLine().trim();

        Review rev = new Review(nextReviewId(), oid, loggedClient.getUserId(),
                loggedClient.getName(), target.getFreelancerId(),
                rating, comment, today());
        reviews.add(rev);
        FileHandler.saveAllReviews(reviews);

        // Update freelancer rating
        for (Freelancer f : freelancers) {
            if (f.getUserId() == target.getFreelancerId()) {
                f.addRating(rating);
                FileHandler.saveAllFreelancers(freelancers);
                break;
            }
        }
        System.out.println("Review submitted! Thank you.");
    }

    private void viewMyReviews() {
        System.out.println("\n--- Reviews About Me ---");
        boolean found = false;
        for (Review r : reviews) {
            if (r.getFreelancerId() == loggedFreelancer.getUserId()) {
                r.displayReview();
                found = true;
            }
        }
        if (!found) System.out.println("No reviews yet.");
    }

    // ============================================================
    //  PAYMENT & WALLET
    // ============================================================

    private void addFunds() {
        System.out.println("Current wallet: Rs. " + loggedClient.getWalletBalance());
        System.out.print("Amount to add (Rs.): ");
        double amt = readDouble();
        if (amt <= 0) { System.out.println("Invalid amount."); return; }
        loggedClient.addFunds(amt);
        FileHandler.saveAllClients(clients);
    }

    private void viewClientPayments() {
        System.out.println("\n--- My Payment History ---");
        boolean found = false;
        for (Payment p : payments) {
            if (p.getClientId() == loggedClient.getUserId()) {
                p.displayPayment();
                found = true;
            }
        }
        if (!found) System.out.println("No payments made yet.");
    }

    // ============================================================
    //  Input Helpers - avoid Scanner issues
    // ============================================================

    // Read integer safely
    private int readInt() {
        try {
            String line = scanner.nextLine().trim();
            return Integer.parseInt(line);
        } catch (Exception e) {
            return -1;
        }
    }

    // Read double safely
    private double readDouble() {
        try {
            String line = scanner.nextLine().trim();
            return Double.parseDouble(line);
        } catch (Exception e) {
            return 0;
        }
    }
}