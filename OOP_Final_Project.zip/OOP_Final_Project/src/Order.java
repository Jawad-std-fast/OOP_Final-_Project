// ============================================================
// Order.java - Represents a placed order
// OOP Concept: Encapsulation
// ============================================================

public class Order {

    // Order status constants
    public static final String PENDING    = "Pending";
    public static final String IN_PROGRESS = "In Progress";
    public static final String COMPLETED  = "Completed";
    public static final String CANCELLED  = "Cancelled";

    private int    orderId;
    private int    clientId;
    private String clientName;
    private int    serviceId;
    private String serviceTitle;
    private int    freelancerId;
    private String freelancerName;
    private double amount;
    private String status;
    private String orderDate;

    public Order(int orderId, int clientId, String clientName,
                 int serviceId, String serviceTitle,
                 int freelancerId, String freelancerName,
                 double amount, String status, String orderDate) {
        this.orderId        = orderId;
        this.clientId       = clientId;
        this.clientName     = clientName;
        this.serviceId      = serviceId;
        this.serviceTitle   = serviceTitle;
        this.freelancerId   = freelancerId;
        this.freelancerName = freelancerName;
        this.amount         = amount;
        this.status         = status;
        this.orderDate      = orderDate;
    }

    // Getters
    public int    getOrderId()        { return orderId; }
    public int    getClientId()       { return clientId; }
    public String getClientName()     { return clientName; }
    public int    getServiceId()      { return serviceId; }
    public String getServiceTitle()   { return serviceTitle; }
    public int    getFreelancerId()   { return freelancerId; }
    public String getFreelancerName() { return freelancerName; }
    public double getAmount()         { return amount; }
    public String getStatus()         { return status; }
    public String getOrderDate()      { return orderDate; }

    // Setter for status only (orders are mostly immutable)
    public void setStatus(String status) { this.status = status; }

    public void displayOrder() {
        System.out.println("------------------------------------------");
        System.out.println("Order ID    : " + orderId);
        System.out.println("Date        : " + orderDate);
        System.out.println("Client      : " + clientName + " (ID: " + clientId + ")");
        System.out.println("Service     : " + serviceTitle + " (ID: " + serviceId + ")");
        System.out.println("Freelancer  : " + freelancerName);
        System.out.printf ("Amount      : Rs. %.2f%n", amount);
        System.out.println("Status      : " + status);
    }

    // File storage: use | separator
    public String toFileString() {
        return orderId + "|" + clientId + "|" + clientName + "|"
                + serviceId + "|" + serviceTitle + "|"
                + freelancerId + "|" + freelancerName + "|"
                + amount + "|" + status + "|" + orderDate;
    }

    public static Order fromFileString(String line) {
        String[] p = line.split("\\|");
        return new Order(
                Integer.parseInt(p[0].trim()),
                Integer.parseInt(p[1].trim()),
                p[2].trim(),
                Integer.parseInt(p[3].trim()),
                p[4].trim(),
                Integer.parseInt(p[5].trim()),
                p[6].trim(),
                Double.parseDouble(p[7].trim()),
                p[8].trim(),
                p[9].trim()
        );
    }

    @Override
    public String toString() {
        return "Order #" + orderId + " | " + serviceTitle + " | Rs." + amount + " | " + status;
    }
}