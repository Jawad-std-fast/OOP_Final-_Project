// ============================================================
// Service.java - Represents a service offered by a freelancer
// OOP Concept: Encapsulation - all fields private with accessors
// ============================================================

public class Service {

    // Service categories as constants (like an enum alternative)
    public static final String SEO       = "SEO";
    public static final String VIDEO     = "Video Editing";
    public static final String MARKETING = "Digital Marketing";
    public static final String DESIGN    = "Graphic Design";
    public static final String WRITING   = "Content Writing";

    private int    serviceId;
    private String title;
    private String description;
    private String category;
    private double price;
    private int    freelancerId;   // Which freelancer offers this service
    private String freelancerName; // Stored for quick display

    public Service(int serviceId, String title, String description,
                   String category, double price,
                   int freelancerId, String freelancerName) {
        this.serviceId      = serviceId;
        this.title          = title;
        this.description    = description;
        this.category       = category;
        this.price          = price;
        this.freelancerId   = freelancerId;
        this.freelancerName = freelancerName;
    }

    // Getters
    public int    getServiceId()      { return serviceId; }
    public String getTitle()          { return title; }
    public String getDescription()    { return description; }
    public String getCategory()       { return category; }
    public double getPrice()          { return price; }
    public int    getFreelancerId()   { return freelancerId; }
    public String getFreelancerName() { return freelancerName; }

    // Setters
    public void setTitle(String title)           { this.title = title; }
    public void setDescription(String desc)      { this.description = desc; }
    public void setPrice(double price)           { this.price = price; }

    public void displayService() {
        System.out.println("------------------------------------------");
        System.out.println("Service ID  : " + serviceId);
        System.out.println("Title       : " + title);
        System.out.println("Category    : " + category);
        System.out.println("Description : " + description);
        System.out.printf ("Price       : Rs. %.2f%n", price);
        System.out.println("Freelancer  : " + freelancerName + " (ID: " + freelancerId + ")");
    }

    // File storage format - use | separator because description might have commas
    public String toFileString() {
        return serviceId + "|" + title + "|" + description + "|"
                + category + "|" + price + "|" + freelancerId + "|" + freelancerName;
    }

    public static Service fromFileString(String line) {
        String[] parts = line.split("\\|");
        return new Service(
                Integer.parseInt(parts[0].trim()),
                parts[1].trim(),
                parts[2].trim(),
                parts[3].trim(),
                Double.parseDouble(parts[4].trim()),
                Integer.parseInt(parts[5].trim()),
                parts[6].trim()
        );
    }

    @Override
    public String toString() {
        return "[" + serviceId + "] " + title + " (" + category + ") - Rs. " + price
                + " by " + freelancerName;
    }
}