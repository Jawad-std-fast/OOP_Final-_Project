/**
 * Thrown when a client tries to spend more than their wallet balance.
 * Demonstrates custom exception handling (OOP: Inheritance from Exception).
 */
public class InsufficientBalanceException extends Exception {
    public InsufficientBalanceException(String message) {
        super(message);
    }
}