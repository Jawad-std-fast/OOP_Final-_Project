/**
 * Interface for any class that can display its full details.
 * Demonstrates Abstraction – all displayable items must implement this.
 */
public interface Displayable {
    void displayDetails();
}